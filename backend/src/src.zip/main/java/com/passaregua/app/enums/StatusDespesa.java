package com.passaregua.app.enums;

public enum StatusDespesa {
    PENDENTE,
    VALIDADA,
    ABATIDA
}