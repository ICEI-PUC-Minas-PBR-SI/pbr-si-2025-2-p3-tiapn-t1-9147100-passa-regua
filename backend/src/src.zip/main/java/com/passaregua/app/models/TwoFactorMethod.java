package com.passaregua.app.models;

public enum TwoFactorMethod {
    EMAIL,
    CELULAR
}

