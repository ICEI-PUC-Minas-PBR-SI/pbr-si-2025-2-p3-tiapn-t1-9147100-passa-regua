package com.passaregua.app.models;

public enum Genero {
    MASCULINO,
    FEMININO,
    PREFIRO_NAO_INFORMAR
}

